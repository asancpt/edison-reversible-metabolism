if (Sys.info()['sysname'] == 'Linux') { .libPaths('./lib') }

install.packages(c('deSolve', 'wnl'))

